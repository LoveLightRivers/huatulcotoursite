export default function Page() {
  return (
    <main style={ fontFamily: 'Arial', padding: '2rem' }>
      <h1>Visites des Baies de Huatulco</h1>
      <p>Rejoignez-nous pour des visites de 8 heures à la découverte des magnifiques 7 Baies de Huatulco.</p>
      <ul>
        <li>Tour de Snorkeling – 60 $ par personne (groupe), 85 $ solo</li>
        <li>Pêche Sportive – 50 $ par heure</li>
        <li>Tour au Coucher du Soleil – 100 $ par couple</li>
      </ul>
      <p>Appeler ou WhatsApp : +52 958 122 55448</p>
    </main>
  );
}
