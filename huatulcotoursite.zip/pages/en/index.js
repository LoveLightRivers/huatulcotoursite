export default function Page() {
  return (
    <main style={ fontFamily: 'Arial', padding: '2rem' }>
      <h1>Huatulco Bay Tours</h1>
      <p>Join us for 8-hour tours exploring the stunning 7 Bays of Huatulco.</p>
      <ul>
        <li>Snorkeling Tour – $60 per person (group), $85 solo</li>
        <li>Sport Fishing – $50 per hour</li>
        <li>Sunset Tour – $100 per couple</li>
      </ul>
      <p>Call or WhatsApp: +52 958 122 55448</p>
    </main>
  );
}
